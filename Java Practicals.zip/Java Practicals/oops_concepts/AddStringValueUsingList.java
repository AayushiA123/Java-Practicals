package oops_concepts;

import java.util.*;

public class AddStringValueUsingList {
	// Driver code
	public static void main(String[] args)
	{

		List<String> ll = new LinkedList<>();
		ll.add("Hello");
		ll.add("World");
		ll.add("Aayushi");

		System.out.println(ll);
	}
	
}