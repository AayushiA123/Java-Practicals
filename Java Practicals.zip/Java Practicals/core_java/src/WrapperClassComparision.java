package aayushi_practice;

/**
 * This program is used to compare two variables of Wrapper class using Wrapper
 * classes.
 *
 * @author Aayushi Agrawal
 * @since 31-08-2023
 */
public class WrapperClassComparision {

	public static void main(String[] args) {
		Integer number1 = 4;
		Integer number2 = 5;
		if (number1 == number2) {
			System.out.println("Both are equals");
		} else {
			System.out.println("Not Equal");
		}
	}

}
