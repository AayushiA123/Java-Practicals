package aayushi_practice;

/**
 * This is simple Hello World Program.
 *
 * @author Aayushi Agrawal
 * @since 28-08-2023
 */
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello");
	}

}
